// Contoh interaksi: saat halaman dimuat, tampilkan pesan di console
console.log("Portofolio berhasil dimuat.");

// Tambah efek pada bagian hero saat diklik
const hero = document.getElementById("hero");
hero.addEventListener("click", () => {
  alert("Terima kasih sudah mengunjungi portofolio saya!");
});
